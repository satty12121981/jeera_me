<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Groups\Controller\Groups' => 'Groups\Controller\GroupsController',
        ),
    ),
	'controller_plugins' => array(
        'invokables' => array(
             
     'ResizePlugin' => 'Album\Controller\Plugin\ResizePlugin',
   
        ),
    ),
	 // The following section is new and should be added to your file
    'router' => array(
        'routes' => array(
            'groups' => array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/groups',
                   'defaults' => array(
						'__NAMESPACE__' => 'Groups\Controller',
                        'controller' => 'groups',
                        'action'     => 'index',
                    ),
                ),
				 
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'groups' => __DIR__ . '/../view',
        ),
    ),
);