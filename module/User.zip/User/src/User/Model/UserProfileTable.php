<?php 

namespace User\Model;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class UserProfileTable extends AbstractTableGateway
{
    protected $table = 'y2m_user_profile';

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new UserProfile());
        $this->initialize();
    } 
    public function getUserProfile($user_profile_id)
    {
        $user_profile_id  = (int) $user_profile_id;
        $rowset = $this->select(array('user_profile_id' => $user_profile_id));
        $row = $rowset->current();         
        return $row;
    }
    public function saveUserProfile(UserProfile $user)
    {
       $data = array(
            'user_profile_dob' => $user->user_profile_dob,
            'user_profile_about_me'  => $user->user_profile_about_me,
			'user_profile_profession'  => $user->user_profile_profession,
			'user_profile_profession_at'  => $user->user_profile_profession_at,
			'user_profile_user_id'  => $user->user_profile_user_id,
			'user_profile_city_id'  => $user->user_profile_city_id,			
			'user_profile_country_id'  => $user->user_profile_country_id,
			'user_address'  => $user->user_address,
			'user_profile_current_location'  => $user->user_profile_current_location,
			'user_profile_phone'  => $user->user_profile_phone,			 
			'user_profile_added_ip_address'  => $user->user_profile_added_ip_address,
			'user_profile_modified_timestamp'  => date("Y-m-d H:i:s"),
			'user_profile_modified_ip_address'  => $user->user_profile_modified_ip_address		
        );
		 $user_profile_id = (int)$user->user_profile_id;
        if ($user_profile_id == 0) {
            $this->insert($data);
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getUserProfile($user_profile_id)) {
                $this->update($data, array('user_profile_id' => $user_profile_id));
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }   
}
