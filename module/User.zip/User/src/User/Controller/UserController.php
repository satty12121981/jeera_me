<?php  
namespace User\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;
use Zend\View\Renderer\PhpRenderer;
use \Exception;
use Zend\Crypt\BlockCipher;
use Zend\Crypt\Password\Bcrypt;	
use User\Auth\BcryptDbAdapter as AuthAdapter;
use Zend\Session\Container;     
use Zend\Authentication\AuthenticationService;
use Zend\Mail;
use User\Model\User;
use User\Model\UserProfile;
use User\Form\Login;       
use User\Form\LoginFilter; 
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part as MimePart;
use Zend\Authentication\Storage\Session;
class UserController extends AbstractActionController
{
	public $form_error ;
	protected $userTable;
	protected $userProfileTable;
   	public function indexAction()
    {	
		 	
    }
	public function registerAction(){
		$error ='';		
		$domain = '';		 
		$request = $this->getRequest();	 
		if ($request->isPost()) {
			$post = $request->getPost();
			if($this->registrationFromValidator($post)){
				$bcrypt = new Bcrypt();
				$password = strip_tags($post['user_password']);
				$password = trim($password);
				$email = strip_tags($post['user_email']);
				$email = trim($email);
				$name = strip_tags($post['user_given_name']);
				$name = trim($name);
				$data['user_password'] = $bcrypt->create($password);
				$user_verification_key = md5('enckey'.rand().time());
				$data['user_verification_key'] = $user_verification_key;
				$data['user_profile_name'] = $this->make_url_friendly($post['user_given_name']);
				$data['user_email'] = $email;
				$data['user_given_name'] = $name;
				$data['user_status'] = "not activated";
				$user = new User();
				$user->exchangeArray($data);
				$insertedUserId = $this->getUserTable()->saveUser($user);
				if($insertedUserId){
					//$this->sendVerificationEmail($user_verification_key,$insertedUserId,$data['user_email']);
					$profile_data['user_profile_user_id'] = $insertedUserId;
					$profile_data['user_profile_country_id'] = strip_tags($post['user_country_id']);
					$profile_data['user_profile_city_id'] = strip_tags($post['user_city_id']);
					$profile_data['user_profile_status'] = "available";
					$userProfile = new UserProfile();
					$userProfile->exchangeArray($profile_data);
					$insertedUserProfileId = $this->getUserProfileTable()->saveUserProfile($userProfile);					 
					$allowed = array('yahoomail.com', 'gmail.com', 'hotmail.com');
					$domain_ar1 = explode('@', $email);
					$domain_ar = array_pop($domain_ar1);
					if (in_array($domain, $allowed))
					{
						$domain =  $domain_ar;
					}

				}else{
					$error = "Some error Occured. Please try again";
				}
			}else{
				$error = $this->form_error;
			}
		}else{
				$error = "Unable to process";
		}
		$return_array= array();		 
		$return_array['process_status'] = (empty($error))?'success':'failed';
		$return_array['process_info'] = $error;	
		$return_array['mail_domain'] = $domain;	
		$result = new JsonModel(array(
		'return_array' => $return_array,      
		));		
		return $result;		
	}
	public function registrationFromValidator($form){
		$user_given_name = strip_tags($form['user_given_name']);
		$user_email  = strip_tags($form['user_email']);
		$user_password = strip_tags($form['user_password']);
		if(empty($user_given_name)||empty($user_email)||empty($user_password)){
			$this->form_error = 'Name email and password are required';
			return false;
		}
		if (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
			$this->form_error = 'Enter a valid email address';
			return false;
		}
		if (strlen($user_password)<5) {
			$this->form_error = 'Password must contain more then  5 characters';
			return false;
		}
		$user_data =  $this->getUserTable()->getUserFromEmail($user_email);
		if(!empty($user_data)){
			$this->form_error = 'Email you are entered is already exist';
			return false;
		}
		return true;
	}
	public function make_url_friendly($string)
	{
		$string = trim($string); 
		$string = preg_replace('/(\W\B)/', '',  $string); 
		$string = preg_replace('/[\W]+/',  '_', $string); 
		$string = str_replace('-', '_', $string);
		if(!$this->checkProfileNameExist($string)){
			return $string; 
		}
		$length = 5;
		$randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
		$string = strtolower($string).'_'.$randomString;
		if(!$this->checkProfileNameExist($string)){
			return $string; 
		} 
		$string = strtolower($string).'_'.time(); 
		return $string; 
	}
	public function checkProfileNameExist($string){
		if($this->getUserTable()->checkProfileNameExist($string)){
			return true;
		}else{
			return false;
		}
	}
	public function sendVerificationEmail($user_verification_key,$insertedUserId,$emailId){
		$this->renderer = $this->getServiceLocator()->get('ViewRenderer');	 
		$user_insertedUserId = md5(md5('userId~'.$insertedUserId));
		$body = $this->renderer->render('user/email/emailVarification.phtml', array('user_verification_key'=>$user_verification_key,'user_insertedUserId'=>$user_insertedUserId));
		$htmlPart = new MimePart($body);
		$htmlPart->type = "text/html";

		$textPart = new MimePart($body);
		$textPart->type = "text/plain";

		$body = new MimeMessage();
		$body->setParts(array($textPart, $htmlPart));

		$message = new Mail\Message();
		$message->setFrom('admin@jeera.com');
		$message->addTo($emailId);
		//$message->addReplyTo($reply);							 
		$message->setSender("Jeera");
		$message->setSubject("Registration confirmation");
		$message->setEncoding("UTF-8");
		$message->setBody($body);
		$message->getHeaders()->get('content-type')->setType('multipart/alternative');

		$transport = new Mail\Transport\Sendmail();
		$transport->send($message);
		return true;
	}
	public function ajaxLoginAction(){
		$error ='';	
		$form = new Login();
		$request = $this->getRequest();
		$activate_user = '';
		if ($request->isPost()) {
			$form->setInputFilter(new LoginFilter());			
			$form->setData($request->getPost());
			if ($form->isValid()) { 
				$data = $request->getPost();
				
					$dbAdapter = $this->getServiceLocator()->get('Zend\Db\Adapter\Adapter');
					$authAdapter = new AuthAdapter($dbAdapter);
					$authAdapter
						->setTableName('y2m_user')
						->setIdentityColumn('user_email')
						->setCredentialColumn('user_password');					
					$authAdapter
						->setIdentity(addslashes($data['user_email']))
						->setCredential($data['user_password']);			
					$result = $authAdapter->authenticate(); 
					if (!$result->isValid()) {	
						if($this->checkUserActive($data['user_email'])){
							$error = "Invalid Email or Password"; 
						}else{
							$error = "This account is not activated yet.. Please check your mail and follow the steps."; 
							$activate_user = 'notactivated';
						}
					} else { 
						$auth = new AuthenticationService();
						$storage = $auth->getStorage();
						$storage->write($authAdapter->getResultRowObject(null,'user_password'));
						if($this->params()->fromPost('rememberme')){ 
							$authNamespace = new Container(Session::NAMESPACE_DEFAULT);
							$authNamespace->getManager()->rememberMe(200000);
						} else{
							$authNamespace = new Container(Session::NAMESPACE_DEFAULT);
							$authNamespace->getManager()->rememberMe(200);
						}
					}
				
			}else{
				$validation_msg = $form->getMessages();
				if(isset($validation_msg['user_email']['isEmpty'])&&$validation_msg['user_email']['isEmpty']!=''){
					$error = $validation_msg['user_email']['isEmpty'];
				}
				else if(isset($validation_msg['user_password']['isEmpty'])&&$validation_msg['user_password']['isEmpty']!=''){
					$error = $validation_msg['user_password']['isEmpty'];
				}
				else if(isset($validation_msg['user_email']['emailAddressInvalidHostname'])&&$validation_msg['user_email']['emailAddressInvalidHostname']!=''){
					$error = $validation_msg['user_email']['emailAddressInvalidHostname'];
				}
				else if(isset($validation_msg['user_email']['hostnameUnknownTld'])&&$validation_msg['user_email']['hostnameUnknownTld']!=''){
					$error = $validation_msg['user_email']['hostnameUnknownTld'];
				}
				else if(isset($validation_msg['user_email']['hostnameLocalNameNotAllowed'])&&$validation_msg['user_email']['hostnameLocalNameNotAllowed']!=''){
					$error = $validation_msg['user_email']['hostnameLocalNameNotAllowed'];
				}
				else{
					$error = "Error occured. PLease try again";
				}
			}
		}else{
			$error ='Unable to process';	
		}
		$return_array= array();		 
		$return_array['process_status'] = (empty($error))?'success':'failed';
		$return_array['process_info'] = $error;
		$return_array['process_user_status'] = $activate_user; 
		$result = new JsonModel(array(
		'return_array' => $return_array,      
		));		
		return $result;
	}
	public function checkUserActive($email){
		$user_data= $this->getUserTable()->getUserFromEmail($email);
		if($user_data->user_status =='live'){
			return true;
		}else{
			return false;
		}
	}
	public function getUserTable(){
		$sm = $this->getServiceLocator();
		return  $this->userTable = (!$this->userTable)?$sm->get('User\Model\UserTable'):$this->userTable;    
	}
	public function getUserProfileTable(){
		$sm = $this->getServiceLocator();
		return  $this->userProfileTable = (!$this->userProfileTable)?$sm->get('User\Model\UserProfileTable'):$this->userProfileTable;    
	}
}
