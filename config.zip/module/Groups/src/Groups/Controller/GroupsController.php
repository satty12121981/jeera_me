<?php 
namespace Groups\Controller;
use Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;	//Return model 
use Groups\Model\Groups; 
use User\Model\User; 
use Groups\Model\UserGroup;
 
use Groups\Model\UserGroupJoiningRequest;
use Zend\Mail;
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part as MimePart;
class GroupsController extends AbstractActionController
{
	protected $groupTable;
	protected $groupThumb ="";	
	protected $Group_Timeline_Path="";	//Image path of Group Timelime
	protected $Group_Thumb_Smaller ="";
	protected $photoTable="";
	protected $userGroupRequestTable;
	protected $userGroupTable;
	protected $groupTagTable=""; 
	protected $ActivityController;
	protected $userNotificationTable;
	protected $userTable;
	protected $countryTable;
	protected $albumTable;
	protected $albumDataTable;
	protected $groupfunctionTable;
	protected $grouppermissionsTable;
	protected $groupSettings;
	protected $tagTable;
	protected $commentTable;
	protected $activityRsvpTable;
	protected $likeTable;
	protected $groupjoiningrequestTable;
	protected $groupJoiningQuestionnaireTable;
	protected $groupQuestionnaireAnswersTable;
	protected $groupQuestionnaireOptionsTable;
	public function __construct(){
        // do some stuff!
		$this->groupThumb = Groups::Group_Thumb_Path;  
		$this->Group_Timeline_Path = Groups::Group_Timeline_Path;  
		$this->Group_Thumb_Smaller = Groups::Group_Thumb_Smaller; 
    }
	public function indexAction(){			
		 
	}
	 
}