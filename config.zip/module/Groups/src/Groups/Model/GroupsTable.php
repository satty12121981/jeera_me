<?php
namespace Groups\Model;
 
use Zend\Db\Sql\Select ;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\TableGateway\Feature\RowGatewayFeature;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
class GroupsTable extends AbstractTableGateway
{ 
    protected $table = 'y2m_group';  
    public function __construct(Adapter $adapter){
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new Groups());
        $this->initialize();
    }
	public function generalGroupList($limit,$offset,$user=0){
		$sub_select = new Select;
		$sub_select2 = new Select;
		$sub_select->from('y2m_group')
				   ->columns(array(new Expression('COUNT(y2m_group.group_id) as member_count'),"group_id"))
				   ->join(array('y2m_user_group'=>'y2m_user_group'),'y2m_group.group_id = y2m_user_group.user_group_group_id',array());
		$sub_select->group('y2m_group.group_id');
		$select_friend1 = new Select;
		$select_friend1->from('y2m_user_friend')
				   ->columns(array("user_friend_sender_user_id"))
				   ->where(array("user_friend_friend_user_id =".$user));
		$select_friend2 = new Select;
		$select_friend2->from('y2m_user_friend')
				   ->columns(array("user_friend_friend_user_id"))
				   ->where(array("user_friend_sender_user_id=".$user));
		$sub_select2->from('y2m_group')
				   ->columns(array(new Expression('COUNT(y2m_group.group_id) as friend_count'),"group_id"))
				   ->join(array('y2m_user_group'=>'y2m_user_group'),'y2m_group.group_id = y2m_user_group.user_group_group_id',array())
				   ->where->in("user_group_user_id",$select_friend1)->or->in("user_group_user_id",$select_friend2);
		$sub_select2->group('y2m_group.group_id');
		$select = new Select;		
		$select->from('y2m_group')
			   ->columns(array('group_id'=>'group_id',
							 'group_title'=>'group_title',
							 'group_seo_title'=>'group_seo_title',
							 'group_description'=>'group_description',
							 'group_location'=>'group_location',
							 'group_city_id'=>'group_city_id',
							 'group_country_id'=>'group_country_id',
							 'group_location_lat'=>'group_location_lat',
							 'group_location_lng'=>'group_location_lng',
							 'group_web_address'=>'group_web_address',
							 'group_welcome_message_members'=>'group_welcome_message_members',
							 'group_web_address'=>'group_web_address',
							 'is_member'=>new Expression('IF(EXISTS(SELECT * FROM y2m_user_group WHERE y2m_user_group.user_group_user_id = '.$user.' AND y2m_user_group.user_group_group_id = y2m_group.group_id AND y2m_user_group.user_group_status=1),1,0)'),
							 'is_admin'=>new Expression('IF(EXISTS(SELECT * FROM y2m_user_group WHERE y2m_user_group.user_group_user_id = '.$user.' AND y2m_user_group.user_group_group_id = y2m_group.group_id AND y2m_user_group.user_group_is_owner = 1),1,0)')
				))
				->join(array('temp_member' => $sub_select), 'temp_member.group_id = y2m_group.group_id',array('member_count'),'left')
				->join(array('temp_friends' => $sub_select2), 'temp_friends.group_id = y2m_group.group_id',array('friend_count'),'left')
				->join("y2m_country","y2m_country.country_id = y2m_group.group_country_id",array("country_code_googlemap","country_title","country_code"),'left')
			    ->join("y2m_city","y2m_city.city_id = y2m_group.group_city_id",array("city"=>"name"),'left')
				->join("y2m_group_photo","y2m_group_photo.group_photo_group_id = y2m_group.group_id",array("group_photo_photo"=>"group_photo_photo"),'left')
				->where(array("y2m_group.group_status = 1"));
		$select->order(array('member_count DESC'));
		$select->limit($limit);
		$select->offset($offset);
		$statement = $this->adapter->createStatement();
		//echo $select->getSqlString();exit;
		$select->prepareStatement($this->adapter, $statement);		 
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	
		return $resultSet->toArray();	
	}
	public function getPlanetinfo($group_id){
		$select = new Select;
		$predicate = new  \Zend\Db\Sql\Where();
		$select->from('y2m_group')
		 ->where(array('y2m_group.group_id' => $group_id));
		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());
		return $resultSet->current();
	}
}