<?php 
namespace User\Controller;
use Zend\View\Helper\HeadScript;
use \Exception;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Renderer\PhpRenderer;
use Zend\Session\Container; 
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter; 
use Zend\Mail;
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part as MimePart; 
class UserProfileController extends AbstractActionController
{    
	protected $userTable;
	protected $userTagTable;
	protected function getViewHelper($helperName){
    	return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
	}	 
    public function memberprofileAction(){
		$error = '';
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
			$this->layout('layout/layout_user');
			$identity = $auth->getIdentity();
			$profilename = $this->params('member_profile');
			$this->layout()->identity = $identity;
			$userinfo = $this->getUserTable()->getUserByProfilename($profilename);
			if(!empty($userinfo)&&$userinfo->user_id){
				$profile_data = $this->getUserTable()->getProfileDetails($userinfo->user_id);
				$user_tags = $this->getUserTagTable()->getAllUserTagsWithCategiry($userinfo->user_id);
				$result = new ViewModel(array('profile_data' => $profile_data, 'error'=>$error,'user_tags'=>$user_tags));		
				return $result; 
			}else{
				$error = "User not exist in the system";
				$result = new ViewModel(array('error'=>$error));		
				return $result;
			}
		}else{return $this->redirect()->toRoute('home', array('action' => 'index'));}
	}	
	public function getUserTable(){
		$sm = $this->getServiceLocator();
		return  $this->userTable = (!$this->userTable)?$sm->get('User\Model\UserTable'):$this->userTable;    
	} 
	public function getUserTagTable(){
		$sm = $this->getServiceLocator();
		return  $this->userTagTable = (!$this->userTagTable)?$sm->get('Tag\Model\UserTagTable'):$this->userTagTable;    
	}
}
