<?php 
#namespance Define
namespace User\Controller;
use Zend\View\Helper\HeadScript;
use \Exception;
#zend Library
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Renderer\PhpRenderer;	//using set template
#session
use Zend\Session\Container; // We need this when using sessions     
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter; 
use Zend\Mail;
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part as MimePart;
 
class UserProfileController extends AbstractActionController
{
    
	protected function getViewHelper($helperName){
    	return $this->getServiceLocator()->get('viewhelpermanager')->get($helperName);
	}	 
    public function indexAction(){			
		 
	}	
	 
}
