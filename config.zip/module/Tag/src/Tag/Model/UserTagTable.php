<?php
namespace Tag\Model;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Expression;
use Zend\Db\Sql\Predicate\Expression as predicate;
class UserTagTable extends AbstractTableGateway
{ 
    protected $table = 'y2m_user_tag';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new UserTag());
        $this->initialize();
    } 
	public function fetchAllUsersOfTag($tag_id)
    {
      	$select = new Select;
		$select->from('y2m_user_tag')
    		->join('y2m_tag', 'y2m_tag.tag_id = y2m_user_tag.user_tag_tag_id', array('tag_title'))
			->join('y2m_user', 'y2m_user.user_id = y2m_user_tag.user_tag_user_id', array('user_first_name', 'user_last_name'))
			->where(array('y2m_user_tag.user_tag_tag_id' => $tag_id))
			->order(array('y2m_user_tag.user_tag_id ASC'));		 
		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	
		return $resultSet;
    }
	public function deleteUserTag($user_tag_id)
    {
        $this->delete(array('user_tag_id' => $user_tag_id));
    }
	public function getAllUserTagsWithCategiry($user_id){
		$select = new Select;
		$select->from('y2m_user_tag')
    		->join('y2m_tag', 'y2m_tag.tag_id = y2m_user_tag.user_tag_tag_id',  array('tags'=>new Expression('GROUP_CONCAT(y2m_tag.tag_title)')))
			->join('y2m_tag_category', 'y2m_tag_category.tag_category_id = y2m_tag.category_id', array('tag_category_title', 'tag_category_icon'))
			->where(array('y2m_user_tag.user_tag_user_id' => $user_id))
			->where(array('y2m_tag_category.tag_category_status' => 1))			 
			->order(array('y2m_tag.tag_title ASC'));		 
		$statement = $this->adapter->createStatement();
		$select->prepareStatement($this->adapter, $statement);
		$resultSet = new ResultSet();
		$resultSet->initialize($statement->execute());	
		return $resultSet;
	}
}