<?php
namespace Application\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Zend\View\Model\ViewModel;
use Zend\Authentication\AuthenticationService;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
class IndexController extends AbstractActionController
{	
	protected $groupTable;
	protected $tagCategoryTable;
	protected $groupTagTable;
	public function indexAction()
    {
		$config = $this->getServiceLocator()->get('Config');
		$groups = $this->getGroupTable()->generalGroupList(6,0);
		$group_general_list = array();
		foreach($groups as $list){
			$group_general_list[] = array('group_id'=> $list['group_id'],
										'group_values'=>$list,
										'tagCategory'=>$this->getTagCategoryTable()->getGroupCategories(5,0,$list['group_id']),
										'tags' =>$this->getGroupTagTable()->fetchAllTagsOfGroup($list['group_id'])
									);		 
		}	 
		$result = new ViewModel(array(
	    'groups' => $group_general_list,'image_folders'=> $config['image_folders'],
            'success'=>true,
        ));		
        return $result; 
    }
	public function ajaxGroupGeneralListAction(){
		$group_general_list = array();
		$request   = $this->getRequest();
		if ($request->isPost()){
			$post = $request->getPost();
			$offset = ($post->get('page'))?$post->get('page')*6:0;
			$groups = $this->getGroupTable()->generalGroupList(6,$offset);		
			foreach($groups as $list){
				$group_general_list[] = array('group_id'=> $list['group_id'],
										'group_values'=>$list,
										'tagCategory'=>$this->getTagCategoryTable()->getGroupCategories(5,0,$list['group_id']),
										'tags' =>$this->getGroupTagTable()->fetchAllTagsOfGroup($list['group_id'])
									);	
			}
		}
		$result = new JsonModel(array(
	    'groups' => $group_general_list,      
        ));		
        return $result; 
	}
	public function getGroupTable(){
		$sm = $this->getServiceLocator();
		return  $this->groupTable = (!$this->groupTable)?$sm->get('Groups\Model\GroupsTable'):$this->groupTable;    
    }
	public function getTagCategoryTable(){
		$sm = $this->getServiceLocator();
		return  $this->tagCategoryTable = (!$this->tagCategoryTable)?$sm->get('Tag\Model\TagCategoryTable'):$this->tagCategoryTable;    
    }
	public function getGroupTagTable(){
		$sm = $this->getServiceLocator();
		return  $this->groupTagTable = (!$this->groupTagTable)?$sm->get('Tag\Model\GroupTagTable'):$this->groupTagTable;    
    }	
}
