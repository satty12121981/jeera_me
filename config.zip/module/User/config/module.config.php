<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'User\Controller\User' => 'User\Controller\UserController',
			'User\Controller\UserProfile' => 'User\Controller\UserProfileController',	
			),
    ),

    // The following section is new and should be added to your file
    'router' => array(
        'routes' => array(			
            'user' => array(
                'type' => 'Literal',
                'priority' => 1000,
                'options' => array(
                    'route' => '/user',
                    'defaults' => array(
						'__NAMESPACE__' => 'User\Controller',
                        'controller' => 'user',
                        'action'     => 'index',
                    ),
                ),
				'may_terminate' => true,				
				'child_routes' => array(
					'register' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/register',
                             
							'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
								'controller' => 'user',
								'action'     => 'register',
							),
                        ),					 
                    ),
					'ajaxLogin' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/ajaxLogin',
                             
							'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
								'controller' => 'user',
								'action'     => 'ajaxLogin',
							),
                        ),					 
                    ),
					'resendverification' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/resendverification',
                             
							'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
								'controller' => 'user',
								'action'     => 'resendverification',
							),
                        ),					 
                    ),					
					
				),
            ),
			'memberprofile' => array(
                'type' => 'segment',
				 'priority' => 1000,
				'may_terminate' => true,
                'options' => array(
                   'route' => '[/:member_profile]',
				   'constraints' => array(
						'member_profile' => '[a-zA-Z0-9_-]*',												 
					),
                    'defaults' => array(
						'__NAMESPACE__' => 'User\Controller',
                        'controller' => 'userprofile',
                        'action'     => 'memberprofile',
                    ),
                ),
                'child_routes' => array(
                    'memberconnect' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/connect/[:member_profile]',
							'constraints' => array(
							'member_profile' => '[a-zA-Z0-9_-]*',												 
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
                                'controller' => 'userprofile',
                                'action'     => 'memberconnect',
                            ),
                        ),
                    ),
					'planets' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/planets',
							'constraints' => array(
							'member_profile' => '[a-zA-Z0-9_-]*',												 
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
                                'controller' => 'userprofile',
                                'action'     => 'planets',
                            ),
                        ),
                    ),
					'photos' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/photos',
							'constraints' => array(
							'member_profile' => '[a-zA-Z0-9_-]*',												 
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
                                'controller' => 'userprofile',
                                'action'     => 'photos',
                            ),
                        ),
                    ),
					 
					'feeds-loadmore' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/morefeeds',
							'constraints' => array(							 										 
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
                                'controller' => 'userprofile',
                                'action'     => 'morefeeds',
                            ),
                        ),
                    ),
					'photos_view' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/photos/[:album_id]',
							'constraints' => array(
							'member_profile' => '[a-zA-Z0-9_-]*',	
							'album_id' => '[a-zA-Z0-9_-]*',								
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Album\Controller',
                                'controller' => 'album',
                                'action'     => 'userAlbumView',
                            ),
                        ),
                    ),
					
					'user_photos' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/photos/user_photos',
							'constraints' => array(
							'member_profile' => '[a-zA-Z0-9_-]*',	
							 				
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Album\Controller',
                                'controller' => 'album',
                                'action'     => 'userPhotos',
                            ),
                        ),
                    ),
					
					'file_view' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/photos/[:album_id]/[:num]',
							'constraints' => array(
							'member_profile' => '[a-zA-Z0-9_-]*',	
							'num' => '[0-9]+',								
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'Album\Controller',
                                'controller' => 'album',
                                'action'     => 'userfile',
                            ),
                        ),
                    ),
					'memberapprove' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/approve/[:member_profile]',
							'constraints' => array(
							'member_profile' => '[a-zA-Z0-9_-]*',												 
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
                                'controller' => 'userprofile',
                                'action'     => 'memberapprove',
                            ),
                        ),
                    ),
					'saveProfilePic' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/saveProfilePic',
							'constraints' => array(
							'member_profile' => '[a-zA-Z0-9_-]*',												 
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
                                'controller' => 'userprofile',
                                'action'     => 'saveProfilePic',
                            ),
                        ),
                    ),
					'profileTop' => array(
						 'type' => 'segment',
						 'options' => array(
						  'route' => '/profileTop/[:member_profile]',          
						   'constraints' => array(
							'member_profile' => '[a-zA-Z0-9_-]*',	         
						   ),
						  'defaults' => array(
						  '__NAMESPACE__' => 'User\Controller',
                                'controller' => 'userprofile',
                                'action'     => 'profileTop',
						  ),
						 ),
						),	
						'updatebio' => array(
							'type' => 'segment',
							'options' => array(
								'route' => '/updatebio',
									 
								'defaults' => array(
									'controller' => 'UserProfile',
									'action'     => 'updatebio',
								),
							),
						),
						'ajaxLoadMoreFriends' => array(
							'type' => 'segment',
							'options' => array(
								'route' => '/ajaxLoadMoreFriends/[:member_profile]',
								'constraints' => array(
								'member_profile' => '[a-zA-Z0-9_-]*',	         
							   ),	 
								'defaults' => array(
									'controller' => 'UserProfile',
									'action'     => 'ajaxLoadMoreFriends',
								),
							),
						),
						'ajaxLoadMorePlanets' => array(
							'type' => 'segment',
							'options' => array(
								'route' => '/ajaxLoadMorePlanets/[:member_profile]',
								'constraints' => array(
								'member_profile' => '[a-zA-Z0-9_-]*',	         
							   ),	 
								'defaults' => array(
									'controller' => 'UserProfile',
									'action'     => 'ajaxLoadMorePlanets',
								),
							),
						),
					'settingsGroupLoadmore' => array(
						 'type' => 'segment',
						 'options' => array(
						  'route' => '/settingsGroupLoadmore',          
						   'constraints' => array(
							  
						   ),
						  'defaults' => array(
						  '__NAMESPACE__' => 'User\Controller',
                                'controller' => 'userprofile',
                                'action'     => 'settingsGroupLoadmore',
						  ),
						 ),
						),	
					'memberreject' => array(
                        'type' => 'segment',
                        'options' => array(
                            'route' => '/reject/[:member_profile]',
							'constraints' => array(
							'member_profile' => '[a-zA-Z0-9_-]*',												 
							),
                            'defaults' => array(
								'__NAMESPACE__' => 'User\Controller',
                                'controller' => 'userprofile',
                                'action'     => 'memberreject',
                            ),
                        ),
                    ),
				),
			),			
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'user' => __DIR__ . '/../view',
        ),
    ),
);

